/**
 * SPDX-FileCopyrightText: (c) 2000 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */

import jquery from 'jquery';
import 'jquery-waypoints/lib/jquery.waypoints.js';
import 'counterup2';

console.log('jquery-custom-element/index.js loaded');

export default class extends HTMLElement {
  connectedCallback() {
    console.log('Custom element connectedCallback fired.');
    this.innerHTML = `<span class="counter">${this.getAttribute('value') || '0'}</span>`;

    console.log('jQuery object:', jquery);
    const counterElement = jquery(this).find('.counter');
    console.log('Counter element found:', counterElement);

    if (counterElement.length > 0) {
      counterElement.counterUp({
        delay: 10,
        time: 1000,
      });
      console.log('counterUp initialized.');
    } else {
      console.log('No counter element found to initialize counterUp.');
    }
  }
}
